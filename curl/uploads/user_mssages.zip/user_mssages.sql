-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 17, 2023 at 10:38 AM
-- Server version: 10.2.44-MariaDB
-- PHP Version: 7.2.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demosite_blazze`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_mssages`
--

CREATE TABLE `user_mssages` (
  `msg_id` int(15) NOT NULL,
  `sender_u_id` varchar(1000) NOT NULL,
  `receiver_u_id` varchar(1000) NOT NULL,
  `mesasge` text NOT NULL,
  `msg_file_path` varchar(5000) NOT NULL,
  `file_type` int(15) NOT NULL COMMENT '1-image,2-video',
  `msg_delete_flag` int(15) NOT NULL COMMENT '1-both,2-sender,3-receiver',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_mssages`
--

INSERT INTO `user_mssages` (`msg_id`, `sender_u_id`, `receiver_u_id`, `mesasge`, `msg_file_path`, `file_type`, `msg_delete_flag`, `created_at`, `updated_at`) VALUES
(1, '6343a8171d533', '627b3edb5d5d8', 'how are you..', '', 0, 0, '2022-11-11 09:24:04', '2022-11-11 09:24:04'),
(2, '6343a8171d533', '627b3edb5d5d8', 'how are you..', '', 0, 0, '2022-11-14 05:37:14', '2022-11-14 05:37:14'),
(3, '627b41113b959', '627b3edb5d5d8', 'hi', '', 0, 0, '2022-11-14 05:38:23', '2022-11-14 05:38:23'),
(4, '627b41113b959', '627b3edb5d5d8', 'hi', '', 0, 0, '2022-11-14 05:40:23', '2022-11-14 05:40:23'),
(5, '627b41113b959', '627b3edb5d5d8', 'where r u ', '', 0, 0, '2022-11-14 07:32:49', '2022-11-14 07:32:49'),
(6, '627b41113b959', '627b3edb5d5d8', 'tried contact last night ?', '', 0, 0, '2022-11-14 07:35:14', '2022-11-14 07:35:14'),
(7, '6343a8171d533', '627b3edb5d5d8', '.', 'assets/message_files/imagesstudy.png', 1, 0, '2022-11-14 07:36:06', '2022-11-14 07:36:06'),
(8, '6347998c9bf6d', '627b3edb5d5d8', 'hey', '', 0, 0, '2022-11-15 10:34:07', '2022-11-15 10:34:07'),
(9, '6347998c9bf6d', '62d8f8ea45e40', 'hello', '', 0, 0, '2022-11-15 10:36:20', '2022-11-15 10:36:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_mssages`
--
ALTER TABLE `user_mssages`
  ADD PRIMARY KEY (`msg_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_mssages`
--
ALTER TABLE `user_mssages`
  MODIFY `msg_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
